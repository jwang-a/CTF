#ifndef FILTERS_H_
#define FILTERS_H_

#include "common.h"

void sharpen(image_t *img);
void emoji(image_t *img);

#endif
