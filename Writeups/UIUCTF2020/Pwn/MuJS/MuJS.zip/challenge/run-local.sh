#!/usr/bin/env bash

set -e
set -x

sudo ./mujs-build/mujs exploit.js
